plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.pathogenguide.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.pathogenguide.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 60
        versionName = "6.0.0"
    }

    buildFeatures { buildConfig = true }
}

// Native Android Views are used deliberately: no WebView, no HTML/CSS runtime.
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.activity:activity-ktx:1.10.0")
    implementation("androidx.recyclerview:recyclerview:1.4.0")
}
