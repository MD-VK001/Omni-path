package com.pathogenguide.app

import android.app.*
import android.content.*
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.*
import android.text.Html
import android.text.InputType
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.switchmaterial.SwitchMaterial
import org.json.JSONArray
import org.json.JSONObject
import java.io.*
import java.text.DateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    private lateinit var root: FrameLayout
    private lateinit var content: LinearLayout
    private lateinit var drawer: LinearLayout
    private lateinit var drawerScrim: View
    private lateinit var search: EditText
    private lateinit var resultLabel: TextView
    private lateinit var list: LinearLayout
    private lateinit var filterBar: LinearLayout
    private lateinit var detailContainer: ScrollView
    private lateinit var detailBody: LinearLayout
    private lateinit var compareBar: TextView
    private var detailToolbar: MaterialToolbar? = null

    private val organisms = mutableListOf<JSONObject>()
    private val vocab = JSONObject()
    private val selectedFilters = mutableMapOf<String, MutableSet<String>>()
    private val selectedCompare = linkedSetOf<String>()
    private val history = mutableListOf<String>()
    private val bookmarks = mutableSetOf<String>()
    private val recent = ArrayDeque<String>()
    private var currentId: String? = null
    private var pathogenType = "All"
    private var category = "All"
    private var filterQuery = ""
    private var filterType: String? = null
    private var dark = false

    private val filterTypes = listOf("conditions","transmission","prevalence","morphology","replication","pathogenesis","diagnostic","treatment","resistance","infectionControl","prevention","epidemiology")
    private val filterLabels = mapOf(
        "conditions" to "Clinical syndromes", "transmission" to "Transmission", "prevalence" to "Prevalence",
        "morphology" to "Morphology", "replication" to "Replication / life cycle", "pathogenesis" to "Pathogenesis",
        "diagnostic" to "Diagnosis", "treatment" to "Treatment", "resistance" to "Resistance",
        "infectionControl" to "Infection control", "prevention" to "Prevention", "epidemiology" to "Epidemiology"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dark = getPreferences(0).getBoolean("dark", false)
        setTheme(if (dark) com.google.android.material.R.style.Theme_Material3_Dark_NoActionBar else com.google.android.material.R.style.Theme_Material3_Light_NoActionBar)
        loadData()
        buildUi()
        renderHome()
    }

    private fun loadData() {
        val text = assets.open("organisms.json").bufferedReader().use { it.readText() }
        val root = JSONObject(text)
        val arr = root.getJSONArray("organisms")
        for (i in 0 until arr.length()) organisms.add(arr.getJSONObject(i))
        val vt = assets.open("vocabularies.json").bufferedReader().use { it.readText() }
        val vo = JSONObject(vt)
        vo.keys().forEach { k -> vocab.put(k, vo.opt(k)) }
        getPreferences(0).getStringSet("bookmarks", emptySet())?.let { bookmarks.addAll(it) }
        getPreferences(0).getStringSet("history", emptySet())?.let { history.addAll(it) }
        getPreferences(0).getStringSet("recent", emptySet())?.let { it.forEach(recent::addLast) }
    }

    private fun buildUi() {
        root = FrameLayout(this)
        root.setBackgroundColor(bg())
        setContentView(root)

        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg()) }
        root.addView(content, FrameLayout.LayoutParams(-1,-1))

        val toolbar = MaterialToolbar(this).apply {
            title = "Pathogen Guide"
            titleTextColor = Color.WHITE
            setBackgroundColor(primary())
            navigationIcon = ContextCompat.getDrawable(this@MainActivity, android.R.drawable.ic_menu_sort_by_size)
            setNavigationOnClickListener { openDrawer() }
        }
        content.addView(toolbar, LinearLayout.LayoutParams(-1, dp(60)))

        search = EditText(this).apply {
            hint = "Search viruses, bacteria, fungi, parasites…"
            singleLine = true
            inputType = InputType.TYPE_CLASS_TEXT
            setPadding(dp(16),0,dp(16),0)
            setBackgroundResource(android.R.drawable.editbox_background)
            setOnEditorActionListener { _,_,_-> performSearch(); true }
            addTextChangedListener(SimpleTextWatcher { renderHome(false) })
        }
        val searchWrap = LinearLayout(this).apply { setPadding(dp(12),dp(8),dp(12),dp(4)) }
        searchWrap.addView(search, LinearLayout.LayoutParams(-1,dp(48)))
        content.addView(searchWrap)

        filterBar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10),dp(4),dp(10),dp(4)) }
        content.addView(filterBar)

        compareBar = TextView(this).apply { setPadding(dp(14),dp(8),dp(14),dp(8)); setTextColor(primary()); visibility = View.GONE; setOnClickListener { showComparison() } }
        content.addView(compareBar)

        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10),dp(4),dp(10),dp(80)) }
        scroll.addView(list)
        content.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))

        drawerScrim = View(this).apply { setBackgroundColor(0x66000000); visibility=View.GONE; setOnClickListener{closeDrawer()} }
        root.addView(drawerScrim, FrameLayout.LayoutParams(-1,-1))
        drawer = buildDrawer()
        val drawerParams = FrameLayout.LayoutParams(dp(320),-1)
        drawerParams.gravity = Gravity.START
        drawerParams.leftMargin = -dp(320)
        root.addView(drawer, drawerParams)
    }

    private fun buildDrawer(): LinearLayout {
        val d = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(bg()); elevation=dp(12).toFloat() }
        val head = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(20),dp(42),dp(16),dp(18)); setBackgroundColor(primary()) }
        TextView(this).apply { text="Pathogen Guide"; textSize=24f; setTextColor(Color.WHITE); head.addView(this) }
        TextView(this).apply { text="293 organisms · offline reference"; textSize=13f; setTextColor(0xCCFFFFFF.toInt()); head.addView(this) }
        d.addView(head)
        val scroll=ScrollView(this); val body=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(8),dp(10),dp(8),dp(24))}; scroll.addView(body); d.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        drawerItem(body,"⌂","Home"){renderHome();closeDrawer()}
        drawerItem(body,"⚄","Random organism"){ if(organisms.isNotEmpty()) showDetails(organisms.random().getString("id")); closeDrawer() }
        drawerItem(body,"⇄","Compare organisms"){openCompareSearch();closeDrawer()}
        drawerItem(body,"★","Bookmarks"){showSaved(false);closeDrawer()}
        drawerItem(body,"◷","Search history"){showSaved(true);closeDrawer()}
        drawerItem(body,"↺","Recently viewed"){showRecent();closeDrawer()}
        section(body,"Appearance")
        val sw=SwitchMaterial(this).apply{ text="Dark mode"; isChecked=dark; setOnCheckedChangeListener{_,v->dark=v;getPreferences(0).edit().putBoolean("dark",v).apply();recreate()} }
        body.addView(sw,LinearLayout.LayoutParams(-1,dp(52)))
        section(body,"Library")
        drawerItem(body,"ⓘ","About / data summary"){showAbout();closeDrawer()}
        drawerItem(body,"↻","Reset local history & bookmarks"){resetLocal();closeDrawer()}
        return d
    }

    private fun drawerItem(parent:LinearLayout, icon:String, label:String, action:()->Unit){
        val row=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),0,dp(8),0);isClickable=true;setBackgroundResource(android.R.drawable.selectableItemBackground);setOnClickListener{action()}}
        TextView(this).apply{text=icon;textSize=20f;setTextColor(primary());gravity=Gravity.CENTER;row.addView(this,LinearLayout.LayoutParams(dp(40),dp(52)))}
        TextView(this).apply{text=label;textSize=16f;setTextColor(fg());row.addView(this,LinearLayout.LayoutParams(-1,dp(52)))}
        parent.addView(row)
    }
    private fun section(parent:LinearLayout,title:String){ TextView(this).apply{text=title.uppercase();textSize=11f;setTextColor(primary());setPadding(dp(14),dp(18),dp(8),dp(6));parent.addView(this)} }

    private fun renderHome(focusSearch:Boolean=true){
        detailContainer?.let { if(it.parent!=null) root.removeView(it) }
        search.visibility=View.VISIBLE; filterBar.visibility=View.VISIBLE
        renderFilters()
        val results=filtered()
        resultLabel?.let{ }
        list.removeAllViews()
        val label=TextView(this).apply{text="${results.size} organisms";textSize=13f;setTextColor(muted());setPadding(dp(4),dp(8),dp(4),dp(6));list.addView(this)}
        results.take(120).forEach{addOrganismCard(it)}
        if(results.isEmpty()) list.addView(emptyView("No matching organisms. Try fewer filters or another term."))
        if(results.size>120) list.addView(emptyView("Showing first 120 results. Refine the search for a shorter list."))
        updateCompareBar()
        if(focusSearch) { }
    }

    private fun renderFilters(){
        filterBar.removeAllViews()
        val scope=HorizontalScrollView(this); val scopeChips=ChipGroup(this).apply{isSingleLine=true}
        val allScope=Chip(this).apply{text="All pathogens";isCheckable=true;isChecked=pathogenType=="All";setOnClickListener{pathogenType="All";category="All";renderHome(false)}};scopeChips.addView(allScope)
        listOf("virology","mycology","bacteriology","parasitology").forEach{pt->val chip=Chip(this).apply{text=prettyType(pt);isCheckable=true;isChecked=pathogenType.equals(pt,true);setOnClickListener{pathogenType=pt;category="All";renderHome(false)}};scopeChips.addView(chip)}
        scope.addView(scopeChips); filterBar.addView(scope,LinearLayout.LayoutParams(-1,dp(42)))

        val catRow=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}
        catRow.addView(TextView(this).apply{text="Category";textSize=13f;setTextColor(muted());setPadding(dp(4),0,dp(8),0)})
        val spinner=Spinner(this)
        val categories=linkedSetOf("All");organisms.filter{pathogenType=="All"||it.optString("pathogenType").equals(pathogenType,true)}.mapTo(categories){it.optString("category")}
        spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,categories.toList().map{if(it=="All")"All categories" else pretty(it)})
        val selectedIndex=categories.toList().indexOf(category).coerceAtLeast(0);spinner.setSelection(selectedIndex,false);var firstCategoryEvent=true;spinner.onItemSelectedListener=object:android.widget.AdapterView.OnItemSelectedListener{override fun onNothingSelected(p:android.widget.AdapterView<*>?){};override fun onItemSelected(p:android.widget.AdapterView<*>?,v:View?,pos:Int,id:Long){if(firstCategoryEvent){firstCategoryEvent=false;return};category=categories.toList()[pos];renderHome(false)}}
        catRow.addView(spinner,LinearLayout.LayoutParams(0,dp(44),1f));filterBar.addView(catRow)

        val types=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        val clear=smallButton("Clear"){selectedFilters.clear();filterType=null;filterQuery="";pathogenType="All";category="All";renderHome()}; types.addView(clear,LinearLayout.LayoutParams(dp(72),dp(40)))
        val hs=HorizontalScrollView(this); val chips=ChipGroup(this).apply{isSingleLine=true}
        filterTypes.forEach{t-> val chip=Chip(this).apply{text=filterLabels[t];isCheckable=true;isChecked=filterType==t;setOnClickListener{filterType=if(filterType==t)null else t;filterQuery="";renderFilters()}};chips.addView(chip)}
        hs.addView(chips); types.addView(hs,LinearLayout.LayoutParams(0,dp(40),1f)); filterBar.addView(types)
        val type=filterType ?: return
        val searchBox=EditText(this).apply{hint="Search ${filterLabels[type]} options…";singleLine=true;setText(filterQuery);setPadding(dp(12),0,dp(12),0);addTextChangedListener(SimpleTextWatcher{filterQuery=text.toString();renderFilterOptions(type)})}
        filterBar.addView(searchBox,LinearLayout.LayoutParams(-1,dp(44)))
        renderFilterOptions(type)
    }

    private fun renderFilterOptions(type:String){
        if(filterBar.childCount<5)return
        while(filterBar.childCount>4)filterBar.removeViewAt(4)
        val group=ChipGroup(this).apply{isSingleLine=false}
        val ids=facetIds(type)
        val q=filterQuery.trim().lowercase()
        ids.filter{ labelFor(it).lowercase().contains(q) || it.lowercase().contains(q)}.take(40).forEach{id->
            val chip=Chip(this).apply{text=labelFor(id);isCheckable=true;isChecked=selectedFilters[type]?.contains(id)==true;setOnClickListener{val s=selectedFilters.getOrPut(type){mutableSetOf()};if(!s.add(id))s.remove(id);if(s.isEmpty())selectedFilters.remove(type);renderHome()}}
            group.addView(chip)
        }
        if(group.childCount==0) group.addView(TextView(this).apply{text="No normalized options. Use the main search for exact source terms.";setTextColor(muted());setPadding(dp(4),dp(6),dp(4),dp(6))})
        filterBar.addView(group)
    }

    private fun facetIds(type:String):List<String>{
        val set=linkedSetOf<String>()
        for(o in organisms) if(matchesTypeCategory(o)) { val a=o.optJSONObject("facets")?.optJSONArray(type); if(a!=null) for(i in 0 until a.length()) set.add(a.optString(i)) }
        return set.sortedBy{labelFor(it)}
    }

    private fun filtered():List<JSONObject>{
        val q=search.text.toString().trim().lowercase()
        return organisms.filter{ o->
            if(!matchesTypeCategory(o)) return@filter false
            if(q.isNotEmpty() && !searchText(o).contains(q)) return@filter false
            for((type,vals) in selectedFilters){val a=o.optJSONObject("facets")?.optJSONArray(type) ?: JSONArray();if(vals.none{v->jsonArrayContains(a,v)}) return@filter false}
            true
        }
    }
    private fun matchesTypeCategory(o:JSONObject):Boolean{
        if(pathogenType!="All"&&!o.optString("pathogenType").equals(pathogenType,true))return false
        if(category!="All"&&o.optString("category")!=category)return false
        return true
    }
    private fun searchText(o:JSONObject):String{val raw=o.toString().lowercase();val facets=o.optJSONObject("facets")?.toString()?.lowercase() ?: "";return "$raw $facets"}
    private fun jsonArrayContains(a:JSONArray,v:String):Boolean{for(i in 0 until a.length())if(a.optString(i)==v)return true;return false}

    private fun addOrganismCard(o:JSONObject){
        val card=MaterialCardView(this).apply{radius=dp(14).toFloat();strokeWidth=1;strokeColor=0x22000000;setCardBackgroundColor(cardBg());setOnClickListener{showDetails(o.getString("id"))}}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(14),dp(12),dp(14))};card.addView(box)
        val top=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}
        TextView(this).apply{text=o.optString("name");textSize=18f;setTextColor(fg());setTypeface(typeface,Typeface.BOLD);top.addView(this,LinearLayout.LayoutParams(0,-2,1f))}
        val star=TextView(this).apply{text=if(bookmarks.contains(o.optString("id")))"★" else "☆";textSize=24f;setTextColor(primary());setOnClickListener{toggleBookmark(o.optString("id"))}}
        top.addView(star,LinearLayout.LayoutParams(dp(40),dp(44)));box.addView(top)
        TextView(this).apply{text="${prettyType(o.optString("pathogenType"))} · ${pretty(o.optString("category"))}";textSize=12f;setTextColor(primary());box.addView(this)}
        val desc=o.optString("description").ifBlank{summary(o)}
        TextView(this).apply{text=desc;maxLines=3;textSize=14f;setTextColor(muted());setPadding(0,dp(8),0,0);box.addView(this)}
        list.addView(card,LinearLayout.LayoutParams(-1,dp(154)).apply{setMargins(0,dp(6),0,dp(6))})
    }

    private fun showDetails(id:String){
        val o=organisms.firstOrNull{it.optString("id")==id}?:return
        detailContainer?.let { if(it.parent!=null) root.removeView(it) }
        detailToolbar?.let { if(it.parent!=null) content.removeView(it) }
        detailToolbar=null
        currentId=id
        recent.remove(id);recent.addFirst(id);while(recent.size>20)recent.removeLast();persist()
        search.visibility=View.GONE;filterBar.visibility=View.GONE;compareBar.visibility=View.GONE;list.removeAllViews()
        detailContainer=ScrollView(this);detailBody=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(14),dp(14),dp(90))};detailContainer.addView(detailBody)
        root.addView(detailContainer,FrameLayout.LayoutParams(-1,-1).apply{topMargin=dp(60)})
        val toolbar=MaterialToolbar(this).apply{title=o.optString("name");titleTextColor=Color.WHITE;setBackgroundColor(primary());navigationIcon=ContextCompat.getDrawable(this@MainActivity,android.R.drawable.ic_media_previous);setNavigationOnClickListener{root.removeView(detailContainer);detailToolbar?.let{content.removeView(it)};detailToolbar=null;renderHome(false)}}
        detailToolbar = toolbar
        content.addView(toolbar,1,LinearLayout.LayoutParams(-1,dp(60)))
        addActionRow(o)
        addTextCard("Overview",o.optString("description"))
        val keys=listOf("epidemiology","morphology","replicationCycle","pathogenesis","clinicalSpectrum","diagnosticApproach","cultureCharacteristics","biochemicalProperties","susceptibilityTesting","treatment","antiviralResistance","antimicrobialResistance","antiparasiticResistance","infectionControl","prevention","virulenceFactors","specialNotes")
        keys.forEach{k->if(o.has(k))addJsonSection(pretty(k),o.opt(k))}
        currentId=id
    }

    private fun addActionRow(o:JSONObject){
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val bm=MaterialButton(this).apply{text=if(bookmarks.contains(o.optString("id")))"★ Saved" else "☆ Save";setOnClickListener{toggleBookmark(o.optString("id"));text=if(bookmarks.contains(o.optString("id")))"★ Saved" else "☆ Save"}}
        row.addView(bm,LinearLayout.LayoutParams(0,dp(48),1f)); val cmp=MaterialButton(this).apply{text="Compare";setOnClickListener{selectedCompare.add(o.optString("id"));openCompareSearch()}};row.addView(cmp,LinearLayout.LayoutParams(0,dp(48),1f))
        detailBody.addView(row)
        val ex=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}; listOf("PDF","TXT","DOC","Share").forEach{label->val b=MaterialButton(this).apply{text=label;setOnClickListener{exportCurrent(label)}};ex.addView(b,LinearLayout.LayoutParams(0,dp(46),1f))};detailBody.addView(ex)
    }

    private fun addTextCard(title:String,text:String){val card=sectionCard(title);card.addView(TextView(this).apply{text=renderRich(text);textSize=15f;setTextColor(fg());setPadding(dp(4),dp(4),dp(4),dp(4))});detailBody.addView(card)}
    private fun addJsonSection(title:String,value:Any?){val card=sectionCard(title);appendJson(card,value);detailBody.addView(card)}
    private fun appendJson(parent:LinearLayout,v:Any?){when(v){is JSONObject->{v.keys().forEach{key->val x=v.opt(key);val h=TextView(this).apply{text=pretty(key);textSize=14f;setTypeface(typeface,Typeface.BOLD);setTextColor(primary());setPadding(dp(4),dp(8),dp(4),dp(2))};parent.addView(h);appendJson(parent,x)} };is JSONArray->{for(i in 0 until v.length())appendJson(parent,v.opt(i))};else->{if(v!=null&&v.toString().isNotBlank())parent.addView(TextView(this).apply{text=renderRich(v.toString());textSize=14f;setTextColor(fg());setPadding(dp(4),dp(2),dp(4),dp(6))})}}}
    private fun sectionCard(title:String):LinearLayout{val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(12),dp(14),dp(12));setBackgroundColor(cardBg())};box.addView(TextView(this).apply{text=title;textSize=19f;setTypeface(typeface,Typeface.BOLD);setTextColor(fg());setPadding(0,0,0,dp(8))});return box.apply{layoutParams=LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))}}}

    private fun renderRich(s:String):CharSequence{val clean=s.replace(Regex("(?is)<script.*?</script>|<style.*?</style>"),"");return if(clean.contains("<")&&clean.contains(">"))Html.fromHtml(clean,Html.FROM_HTML_MODE_LEGACY)else clean.replace("&nbsp;"," ")}

    private fun openCompareSearch(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(12),dp(18),0)}
        val q=EditText(this).apply{hint="Search organisms to compare…";singleLine=true}
        box.addView(q,LinearLayout.LayoutParams(-1,dp(50)))
        val results=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val scroll=ScrollView(this).apply{addView(results)};box.addView(scroll,LinearLayout.LayoutParams(-1,dp(300)))
        fun update(){results.removeAllViews();val s=q.text.toString().trim().lowercase();organisms.filter{searchText(it).contains(s)}.take(40).forEach{o->val c=Chip(this).apply{text="${o.optString("name")} · ${prettyType(o.optString("pathogenType"))}";isCheckable=true;isChecked=selectedCompare.contains(o.optString("id"));setOnClickListener{val id=o.optString("id");if(!selectedCompare.add(id))selectedCompare.remove(id);isChecked=selectedCompare.contains(id);updateCompareBar()}};results.addView(c)}}
        q.addTextChangedListener(SimpleTextWatcher{update()});update()
        MaterialAlertDialogBuilder(this).setTitle("Compare organisms (2–6)").setView(box).setNegativeButton("Close",null).setPositiveButton("Compare"){_,_->if(selectedCompare.size>=2)showComparison() else toast("Select at least two organisms")}.show()
    }
    private fun updateCompareBar(){if(selectedCompare.isEmpty()){compareBar.visibility=View.GONE;return};compareBar.visibility=View.VISIBLE;compareBar.text="${selectedCompare.size} selected · Tap to compare"}
    private fun showComparison(){if(selectedCompare.size<2){toast("Select at least two organisms");return};val chosen=organisms.filter{selectedCompare.contains(it.optString("id"))};val text=StringBuilder("Comparison summary\n\n");chosen.forEach{o->text.append(o.optString("name")).append(" — ").append(prettyType(o.optString("pathogenType"))).append("\n");text.append(summary(o)).append("\n\n")};MaterialAlertDialogBuilder(this).setTitle("Pathogen comparison").setMessage(text.toString()).setPositiveButton("Export"){_,_->exportComparison(chosen)}.setNegativeButton("Close",null).show()}

    private fun showSaved(historyMode:Boolean){val items=if(historyMode)history.toList() else bookmarks.toList();val b=StringBuilder();if(items.isEmpty())b.append("Nothing saved yet.") else items.forEachIndexed{i,id->val o=organisms.firstOrNull{it.optString("id")==id};b.append("• ").append(o?.optString("name")?:id).append("\n")};MaterialAlertDialogBuilder(this).setTitle(if(historyMode)"Search history" else "Bookmarks").setMessage(b.toString()).setPositiveButton("Close",null).show()}
    private fun showRecent(){val names=recent.mapNotNull{id->organisms.firstOrNull{it.optString("id")==id}?.optString("name")};MaterialAlertDialogBuilder(this).setTitle("Recently viewed").setMessage(if(names.isEmpty())"Nothing viewed yet." else names.joinToString("\n") {"• $it"}).setPositiveButton("Close",null).show()}
    private fun showAbout(){MaterialAlertDialogBuilder(this).setTitle("Pathogen Guide").setMessage("Offline clinical reference\n\n${organisms.size} organisms\nVirology 60 · Mycology 80 · Bacteriology 99 · Parasitology 54\n\nNative Kotlin Android implementation. Data is bundled on-device.").setPositiveButton("OK",null).show()}
    private fun resetLocal(){bookmarks.clear();history.clear();recent.clear();persist();toast("Local history and bookmarks cleared")}

    private fun toggleBookmark(id:String){if(bookmarks.contains(id))bookmarks.remove(id)else bookmarks.add(id);persist();renderHome(false)}
    private fun performSearch(){val q=search.text.toString().trim();if(q.isNotBlank()){history.remove(q);history.add(0,q);while(history.size>30)history.removeLast();persist();renderHome(false);hideKeyboard()}}

    private fun exportCurrent(kind:String){val id=currentId?:return;val o=organisms.firstOrNull{it.optString("id")==id}?:return;val title=o.optString("name");val text=plainDetails(o);when(kind){"PDF"->printPdf(title,text);"TXT"->createFile("text/plain","$title.txt",text);"DOC"->createFile("application/msword","$title.doc",docText(text));"Share"->share(title,text)}}
    private fun exportComparison(chosen:List<JSONObject>){val text=chosen.joinToString("\n\n") {"${it.optString("name")} — ${prettyType(it.optString("pathogenType"))}\n${plainDetails(it)}"};printPdf("Pathogen comparison",text)}
    private fun createFile(mime:String,name:String,text:String){pendingExport=text;pendingMime=mime
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply{type=mime;putExtra(Intent.EXTRA_TITLE,name)},9001)}
    private var pendingExport:String?=null;private var pendingMime:String?=null
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(requestCode==9001&&resultCode==RESULT_OK&&data?.data!=null){contentResolver.openOutputStream(data.data!!)?.use{it.write((pendingExport ?: "").toByteArray())};pendingExport=null}}
    private fun share(title:String,text:String){startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_SUBJECT,title);putExtra(Intent.EXTRA_TEXT,text)},"Share organism details"))}
    private fun printPdf(title:String,text:String){val pm=getSystemService(PRINT_SERVICE) as PrintManager;pm.print(title,TextPrintAdapter(title,text),PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setColorMode(PrintAttributes.COLOR_MODE_COLOR).build())}

    private fun plainDetails(o:JSONObject):String{val b=StringBuilder();b.append(o.optString("name")).append("\n").append(prettyType(o.optString("pathogenType"))).append(" / ").append(pretty(o.optString("category"))).append("\n\n");b.append(strip(o.optString("description"))).append("\n\n");val keys=o.keys();while(keys.hasNext()){val k=keys.next();if(setOf("id","name","description","pathogenType","specialty","category","facets","facetLabels").contains(k))continue;b.append("## ").append(pretty(k)).append("\n");appendPlain(b,o.opt(k),0);b.append("\n")};return b.toString()}
    private fun appendPlain(b:String,v:Any?,indent:Int){when(v){is JSONObject->{v.keys().forEach{k->b.append("  ".repeat(indent)).append(pretty(k)).append(": ");val x=v.opt(k);if(x is JSONObject||x is JSONArray){b.append("\n");appendPlain(b,x,indent+1)}else b.append(strip(x.toString())).append("\n")}};is JSONArray->{for(i in 0 until v.length())appendPlain(b,v.opt(i),indent)};else->b.append(strip(v?.toString()?:"")).append("\n")}}
    private fun docText(s:String)=s

    private fun strip(s:String)=Html.fromHtml(s.replace(Regex("(?is)<script.*?</script>|<style.*?</style>"),""),Html.FROM_HTML_MODE_LEGACY).toString()
    private fun summary(o:JSONObject)=o.optString("description").let{if(it.length>220)it.take(220)+"…" else it}
    private fun labelFor(id:String):String{val labels=vocab.optJSONObject("labels");return labels?.optString(id,id)?:id}
    private fun prettyType(s:String)=s.replaceFirstChar{it.uppercase()}
    private fun pretty(s:String)=s.replace(Regex("([a-z])([A-Z])"),"$1 $2").replace('_',' ').replaceFirstChar{it.uppercase()}
    private fun emptyView(s:String)=TextView(this).apply{text=s;textSize=15f;setTextColor(muted());gravity=Gravity.CENTER;setPadding(dp(24),dp(24),dp(24),dp(24))}
    private fun smallButton(t:String,a:()->Unit)=MaterialButton(this).apply{text=t;setOnClickListener{a()}}
    private fun openDrawer(){drawerScrim.visibility=View.VISIBLE;drawer.animate().translationX(dp(320).toFloat()).setDuration(180).start()}
    private fun closeDrawer(){drawer.animate().translationX(0f).setDuration(180).withEndAction{drawerScrim.visibility=View.GONE}.start()}
    private fun persist(){getPreferences(0).edit().putStringSet("bookmarks",bookmarks).putStringSet("history",history.toSet()).putStringSet("recent",recent.toSet()).apply()}
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
    private fun hideKeyboard(){(getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(search.windowToken,0)}
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun bg()=if(dark)Color.rgb(16,23,22) else Color.rgb(247,249,250)
    private fun cardBg()=if(dark)Color.rgb(27,35,34) else Color.WHITE
    private fun fg()=if(dark)Color.WHITE else Color.rgb(25,31,30)
    private fun muted()=if(dark)0xFFB8C4C2.toInt() else 0xFF5F6B69.toInt()
    private fun primary()=Color.rgb(11,110,105)

    private inner class TextPrintAdapter(private val title:String,private val text:String):PrintDocumentAdapter(){
        private var file:File?=null
        override fun onLayout(oldAttributes:PrintAttributes?,newAttributes:PrintAttributes?,cancellationSignal:CancellationSignal?,callback:LayoutResultCallback?,extras:Bundle?){if(cancellationSignal?.isCanceled==true){callback?.onLayoutCancelled();return};callback?.onLayoutFinished(PrintDocumentInfo.Builder(title).setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).setPageCount(1).build(),true)}
        override fun onWrite(pages:Array<out PageRange>?,destination:ParcelFileDescriptor?,cancellationSignal:CancellationSignal?,callback:WriteResultCallback?){try{val fd=destination?.fileDescriptor ?: run { callback?.onWriteFailed("No destination"); return };val doc=PdfDocument();val page=doc.startPage(PdfDocument.PageInfo.Builder(595,842,1).create());val c=page.canvas;val paint=Paint().apply{color=Color.BLACK;textSize=10f};var y=35f;for(line in text.split("\n")){if(y>810){break};c.drawText(line.take(100),24f,y,paint);y+=14f};doc.finishPage(page);FileOutputStream(fd).use{doc.writeTo(it)};doc.close();callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))}catch(e:Exception){callback?.onWriteFailed(e.message)}}
    }
}

private class SimpleTextWatcher(private val changed:(CharSequence)->Unit):android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){changed(s?:"")};override fun afterTextChanged(s:android.text.Editable?){} }
