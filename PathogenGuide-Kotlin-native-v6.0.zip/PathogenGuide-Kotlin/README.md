# Pathogen Guide — Native Kotlin Android v6.0

This version is a **real native Android application written in Kotlin**. It no longer uses WebView, HTML/CSS, Capacitor, or WebToApp for the application UI.

## Preserved data
- 293 organisms
- 60 virology
- 80 mycology
- 99 bacteriology
- 54 parasitology
- Cross-pathogen normalized facets and vocabulary
- Specialty-specific organism fields

The canonical database is bundled offline at:
`app/src/main/assets/organisms.json`

## Native features
- Native Android toolbar and navigation drawer
- Native search field and scrolling lists
- Native filter chips and filter-option search
- Cross-pathogen filtering
- Search-driven comparison of 2–6 organisms
- Native organism detail screens
- Bookmarks, history and recently viewed organisms
- Light/dark mode switch
- Native Android share intent
- Native TXT/DOC document creation
- Native Android print/PDF pipeline using `PdfDocument`/`PrintManager`
- Epidemiology and other legacy HTML fragments rendered as Android `Spanned` text rather than WebView

## Build
Open the folder in Android Studio and let Gradle sync the Android/Kotlin plugins and dependencies, then run:

```bash
./gradlew assembleDebug
```

or use **Build > Build APK(s)** in Android Studio.

No WebView or WebToApp runtime is required for this native version.
